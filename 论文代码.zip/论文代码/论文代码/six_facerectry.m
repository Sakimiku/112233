clear all

%����ʶ������
nrec=8;
%ÿ������ʶ�����Ƭ��
num_of_rec=7;
%���ڲ��Ե���Ƭ����
num_of_test=88;
%���ڲ��ԵĲ�����š�����
testbegin=1;
testend=200;
testbuchang=1;

%��¼��������飬����1��nrec*num_of_rec��ʶ�������������nrec*num_of_rec+1�Ƿ�����
myrec=zeros(num_of_test,nrec*num_of_rec+1);

%����������Ƭ����
%{
datasavename = strcat('facesample200.mat');
load(datasavename);
finals2002=finals;
datasavename = strcat('facetest200.mat');
load(datasavename);
finals2001=finals;
%}
% datasavename = strcat('facesample180.mat');
% load(datasavename);
% finals180s=finals;
% datasavename = strcat('facetest180.mat');
% load(datasavename);
% finals180t=finals;
% datasavename=strcat('six_facesample_180var.mat');
% load(datasavename);
% finals180sv=finals;
% datasavename=strcat('six_facetest_180var.mat');
% load(datasavename);
% finals180tv=finals;

% datasavename = strcat('facesample160.mat');
% load(datasavename);
% finals160s=finals;
% datasavename = strcat('facetest160.mat');
% load(datasavename);
% finals160t=finals;
% datasavename=strcat('six_facesample_160var.mat');
% load(datasavename);
% finals160sv=finals;
% datasavename=strcat('six_facetest_160var.mat');
% load(datasavename);
% finals160tv=finals;

% datasavename = strcat('facesample140.mat');
% load(datasavename);
% finals140s=finals;
% datasavename = strcat('facetest140.mat');
% load(datasavename);
% finals140t=finals;
% datasavename=strcat('six_facesample_140var.mat');
% load(datasavename);
% finals140sv=finals;
% datasavename=strcat('six_facetest_140var.mat');
% load(datasavename);
% finals140tv=finals;

% datasavename = strcat('facesample120.mat');
% load(datasavename);
% finals120s=finals;
% datasavename = strcat('facetest120.mat');
% load(datasavename);
% finals120t=finals;
% datasavename=strcat('six_facesample_120var.mat');
% load(datasavename);
% finals120sv=finals;
% datasavename=strcat('six_facetest_120var.mat');
% load(datasavename);
% finals120tv=finals;

% datasavename = strcat('facesample100.mat');
% load(datasavename);
% finals100s=finals;
% datasavename = strcat('facetest100.mat');
% load(datasavename);
% finals100t=finals;
% datasavename=strcat('six_facesample_100var.mat');
% load(datasavename);
% finals100sv=finals;
% datasavename=strcat('six_facetest_100var.mat');
% load(datasavename);
% finals100tv=finals;

% datasavename = strcat('facesample80.mat');
% load(datasavename);
% finals80s=finals;
% datasavename = strcat('facetest80.mat');
% load(datasavename);
% finals80t=finals;
% datasavename=strcat('six_facesample_80var.mat');
% load(datasavename);
% finals80sv=finals;
% datasavename=strcat('six_facetest_80var.mat');
% load(datasavename);
% finals80tv=finals;

% datasavename = strcat('facesample60.mat');
% load(datasavename);
% finals60s=finals;
% datasavename = strcat('facetest60.mat');
% load(datasavename);
% finals60t=finals;
% datasavename=strcat('six_facesample_60var.mat');
% load(datasavename);
% finals60sv=finals;
% datasavename=strcat('six_facetest_60var.mat');
% load(datasavename);
% finals60tv=finals;

% datasavename = strcat('facesample40.mat');
% load(datasavename);
% finals40s=finals;
% datasavename = strcat('facetest40.mat');
% load(datasavename);
% finals40t=finals;
% datasavename=strcat('six_facesample_40var.mat');
% load(datasavename);
% finals40sv=finals;
% datasavename=strcat('six_facetest_40var.mat');
% load(datasavename);
% finals40tv=finals;

%canny������ȡ����
datasavename = strcat('D:\ͼ��ʶ�����\���Ĵ���\��������ʱ���ɵ��м�����\�����������\��������\facesample5.mat');
load(datasavename);
finalscs=finals;
datasavename = strcat('D:\ͼ��ʶ�����\���Ĵ���\��������ʱ���ɵ��м�����\�����������\facetest.mat');
load(datasavename);
finalsct=finals;
datasavename=strcat('D:\ͼ��ʶ�����\���Ĵ���\��������ʱ���ɵ��м�����\�����������\��������\facesample5_var.mat');
load(datasavename);
finalscsv=finals;
datasavename=strcat('D:\ͼ��ʶ�����\���Ĵ���\��������ʱ���ɵ��м�����\�����������\six_facetest_var.mat');
load(datasavename);
finalsctv=finals;
%�����������Ƭ����
% datasavename = strcat('D:\ͼ��ʶ�����\���Ĵ������\����ʶ�����\��������ʱ���ɵ��м�����\�����������\six_facetest.mat');
% load(datasavename);
% finals11=finals;



%���ڼ���׼ȷ��
k=0;
%���ڼ�¼���ʶ��������
temprec=zeros(4,1);
num_pass=0;
num_notpass=0;
%ȷ������������ʶ������е�Ȩ��
varweight=0.5;
minweight=1;
for varweight=0:0
for testbegin=3:3%5:2:9
   % testbegin
for testend=118:118%100:2:200%testbegin+1:2:200
   % num_pass
   % num_notpass
  %  temprec
  %  testend
    for testbuchang=38:38%10:2:50%10:2:50
   %     testbuchang

        %����ѭ���������������ظ�����
        if mod(testend-testbegin-1,testbuchang)~=0 || testend<=testbegin
	%���ڼ�¼ʵ��ѭ��������������ѭ������
            num_pass=num_pass+1;
        else
            num_notpass=num_notpass+1;
        
for i=1:num_of_test
    for j=1:nrec*num_of_rec
%        rectest200=kron(finals2001(i,testbegin:testbuchang:testend),[1 0])+kron(finals2001(i,testbegin+1:testbuchang:testend),[0 1]);
 %       recsample200=kron(finals2002(j,testbegin:testbuchang:testend),[1 0])+kron(finals2002(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest180t=kron(finals180t(i,testbegin:testbuchang:testend),[1 0])+kron(finals180t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest180tv=kron(varweight*finals180tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals180tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample180s=kron(finals180s(j,testbegin:testbuchang:testend),[1 0])+kron(finals180s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample180sv=kron(varweight*finals180sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals180sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest180=[rectest180t rectest180tv];
%         recsample180=[recsample180s recsample180sv];
%         
%         rectest160t=kron(finals160t(i,testbegin:testbuchang:testend),[1 0])+kron(finals160t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest160tv=kron(varweight*finals160tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals160tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample160s=kron(finals160s(j,testbegin:testbuchang:testend),[1 0])+kron(finals160s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample160sv=kron(varweight*finals160sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals160sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest160=[rectest160t rectest160tv];
%         recsample160=[recsample160s recsample160sv];
%         
%         rectest140t=kron(finals140t(i,testbegin:testbuchang:testend),[1 0])+kron(finals140t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest140tv=kron(varweight*finals140tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals140tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample140s=kron(finals140s(j,testbegin:testbuchang:testend),[1 0])+kron(finals140s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample140sv=kron(varweight*finals140sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals140sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest140=[rectest140t rectest140tv];
%         recsample140=[recsample140s recsample140sv];
%         
%         rectest120t=kron(finals120t(i,testbegin:testbuchang:testend),[1 0])+kron(finals120t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest120tv=kron(varweight*finals120tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals120tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample120s=kron(finals120s(j,testbegin:testbuchang:testend),[1 0])+kron(finals120s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample120sv=kron(varweight*finals120sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals120sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest120=[rectest120t rectest120tv];
%         recsample120=[recsample120s recsample120sv];
% 
%         rectest100t=kron(finals100t(i,testbegin:testbuchang:testend),[1 0])+kron(finals100t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest100tv=kron(varweight*finals100tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals100tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample100s=kron(finals100s(j,testbegin:testbuchang:testend),[1 0])+kron(finals100s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample100sv=kron(varweight*finals100sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals100sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest100=[rectest100t rectest100tv];
%         recsample100=[recsample100s recsample100sv];
% 
%         rectest80t=kron(finals80t(i,testbegin:testbuchang:testend),[1 0])+kron(finals80t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest80tv=kron(varweight*finals80tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals80tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample80s=kron(finals80s(j,testbegin:testbuchang:testend),[1 0])+kron(finals80s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample80sv=kron(varweight*finals80sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals80sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest80=[rectest80t rectest80tv];
%         recsample80=[recsample80s recsample80sv];
% 
%         rectest60t=kron(finals60t(i,testbegin:testbuchang:testend),[1 0])+kron(finals60t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest60tv=kron(varweight*finals60tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals60tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample60s=kron(finals60s(j,testbegin:testbuchang:testend),[1 0])+kron(finals60s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample60sv=kron(varweight*finals60sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals60sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest60=[rectest60t rectest60tv];
%         recsample60=[recsample60s recsample60sv];
%         
%         rectest40t=kron(finals40t(i,testbegin:testbuchang:testend),[1 0])+kron(finals40t(i,testbegin+1:testbuchang:testend),[0 1]);
%         rectest40tv=kron(varweight*finals40tv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals40tv(i,testbegin+1:testbuchang:testend),[0 1]);
%         recsample40s=kron(finals40s(j,testbegin:testbuchang:testend),[1 0])+kron(finals40s(j,testbegin+1:testbuchang:testend),[0 1]);
%         recsample40sv=kron(varweight*finals40sv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finals40sv(j,testbegin+1:testbuchang:testend),[0 1]);
%         rectest40=[rectest40t rectest40tv];
%         recsample40=[recsample40s recsample40sv];
        
        rectestct=kron(finalsct(i,testbegin:testbuchang:testend),[1 0])+kron(finalsct(i,testbegin+1:testbuchang:testend),[0 1]);
        rectestctv=kron(varweight*finalsctv(i,testbegin:testbuchang:testend),[1 0])+kron(minweight*finalsctv(i,testbegin+1:testbuchang:testend),[0 1]);
        recsamplecs=kron(finalscs(j,testbegin:testbuchang:testend),[1 0])+kron(finalscs(j,testbegin+1:testbuchang:testend),[0 1]);
        recsamplecsv=kron(varweight*finalscsv(j,testbegin:testbuchang:testend),[1 0])+kron(minweight*finalscsv(j,testbegin+1:testbuchang:testend),[0 1]);
        rectestc=[rectestct rectestctv];
        recsamplec=[recsamplecs recsamplecsv];

  %{        
        var180=abs(var(rectest180)-var(recsample180))/varweight;
        rectest160=kron(finals1601(i,testbegin:testbuchang:testend),[1 0])+kron(finals1601(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample160=kron(finals1602(j,testbegin:testbuchang:testend),[1 0])+kron(finals1602(j,testbegin+1:testbuchang:testend),[0 1]);
        var160=abs(var(rectest160)-var(recsample160))/varweight;
        rectest140=kron(finals1401(i,testbegin:testbuchang:testend),[1 0])+kron(finals1401(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample140=kron(finals1402(j,testbegin:testbuchang:testend),[1 0])+kron(finals1402(j,testbegin+1:testbuchang:testend),[0 1]);
        var140=abs(var(rectest140)-var(recsample140))/varweight;
        rectest120=kron(finals1201(i,testbegin:testbuchang:testend),[1 0])+kron(finals1201(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample120=kron(finals1202(j,testbegin:testbuchang:testend),[1 0])+kron(finals1202(j,testbegin+1:testbuchang:testend),[0 1]);
        var120=abs(var(rectest120)-var(recsample120))/varweight;
        rectest100=kron(finals1001(i,testbegin:testbuchang:testend),[1 0])+kron(finals1001(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample100=kron(finals1002(j,testbegin:testbuchang:testend),[1 0])+kron(finals1002(j,testbegin+1:testbuchang:testend),[0 1]);
        var100=abs(var(rectest100)-var(recsample100))/varweight;
        rectest80=kron(finals801(i,testbegin:testbuchang:testend),[1 0])+kron(finals801(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample80=kron(finals802(j,testbegin:testbuchang:testend),[1 0])+kron(finals802(j,testbegin+1:testbuchang:testend),[0 1]);
        var80=abs(var(rectest80)-var(recsample80))/varweight;
        rectest60=kron(finals601(i,testbegin:testbuchang:testend),[1 0])+kron(finals601(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample60=kron(finals602(j,testbegin:testbuchang:testend),[1 0])+kron(finals602(j,testbegin+1:testbuchang:testend),[0 1]);
        var60=abs(var(rectest60)-var(recsample60))/varweight;
        rectest40=kron(finals401(i,testbegin:testbuchang:testend),[1 0])+kron(finals401(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample40=kron(finals402(j,testbegin:testbuchang:testend),[1 0])+kron(finals402(j,testbegin+1:testbuchang:testend),[0 1]);
        var40=abs(var(rectest40)-var(recsample40))/varweight;

        rectest1=kron(finals11(i,testbegin:testbuchang:testend),[1 0])+kron(finals11(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample1=kron(finals12(j,testbegin:testbuchang:testend),[1 0])+kron(finals12(j,testbegin+1:testbuchang:testend),[0 1]);
        var1=abs(var(rectest1)-var(recsample1))/varweight;
       
        vartotal=var180+var160+var140+var120+var100+var80+var60+var40+var1;

        rectest2=kron(finals21(i,testbegin:testbuchang:testend),[1 0])+kron(finals21(i,testbegin+1:testbuchang:testend),[0 1]);
        recsample2=kron(finals22(j,testbegin:testbuchang:testend),[1 0])+kron(finals22(j,testbegin+1:testbuchang:testend),[0 1]);
        var2=abs(var(rectest2)-var(recsample2))/varweight;

 %} 
   %     vartotal+norm([rectest180 rectest160 rectest140 rectest120 rectest100 rectest80 rectest60 rectest40 rectest1]-[recsample180 recsample160 recsample140 recsample120 recsample100 recsample80 recsample60 recsample40 recsample1])
%        myrec(i,j)=norm([rectest160 rectest140 rectest120 rectest100 rectest80 rectest60 rectest40 rectest1]-[recsample160 recsample140 recsample120 recsample100 recsample80 recsample60 recsample40 recsample1]);
        
%        myrec(i,j)=norm([rectest180 rectest160 rectest140 rectest120 rectest100 rectest80 rectest60 rectest40 rectestc]-[recsample180 recsample160 recsample140 recsample120 recsample100 recsample80 recsample60 recsample40 recsamplec]);
%         myrec(i,j)=norm([rectest180 rectest160 rectest140 rectest120 rectest100 rectest80 rectest60 rectest40 0.5*rectestc]-[recsample180 recsample160 recsample140 recsample120 recsample100 recsample80 recsample60 recsample40 0.5*recsamplec]);
        if j==1
            myrec(i,nrec*num_of_rec+1)=j;
        else
            if myrec(i,j)<myrec(i,myrec(i,nrec*num_of_rec+1))
                myrec(i,nrec*num_of_rec+1)=j;
            end
        end
    end
end

for i=1:num_of_test
    for j=1:num_of_rec
        if myrec(i,nrec*num_of_rec+1)==floor(((i-1)*nrec)/num_of_test)*num_of_rec+j
            k=k+1;
        end
    end
end
k;
k/num_of_test;


    temprec1(1,1)=k/num_of_test;
    temprec1(2,1)=testbegin;
    temprec1(3,1)=testend;
    temprec1(4,1)=testbuchang;
    [temprec1;varweight]
if temprec(1,1)<k/num_of_test
    temprec(1,1)=k/num_of_test;
    temprec(2,1)=testbegin;
    temprec(3,1)=testend;
    temprec(4,1)=testbuchang;
    temprec
    varweight
end
k=0;
        end
    end
end
end
end


%{
temp=zeros(200,1);
load('bicegotest2','.mat');
for q=1:20:140
    if q==1
        temp=finals(q,:);
    else
        temp=[temp;finals(q,:)];
    end
end
finals=temp;
save('bicegosample2.mat','finals');
%}  
%{
for i=1:2:10
    for j=2:2:20
        for k=4:2:10
            if mod(j-i+1,k)~=0 | j<=i
                break;
            else
                disp(strcat('i=',num2str(i),'j=',num2str(j),'k=',num2str(k)));
            end
        end
    end
end
%}