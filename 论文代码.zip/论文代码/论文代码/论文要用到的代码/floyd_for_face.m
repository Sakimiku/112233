%function [distance,path]=dijkstra(A,s,e)
function [D]=floyd(a)
% [D,R]=floyd(a)
%
% Floyd�㷨�����·�����������aΪ����Ĵ�Ȩ�ڽӾ���Inf��ʾ���㲻ͨ��
% �������DΪ�������̾��룬����RΪ���·����

n=size(a,1);
D=a;
%for i=1:n
%    for j=1:n
%        R{i,j}=[num2str(i), num2str(j)];
%    end
%end

for k=1:n
    for i=1:n
        for j=1:n
            if D(i,k)+D(k,j)<D(i,j)
                D(i,j)=D(i,k)+D(k,j);
 %               l=length(R{i,k})-length(num2str(k));
  %              R{i,j}=[R{i,k}(1:l),R{k,j}];
            end
        end
    end
end


% Sample input and output
%
% >> w=[     0    50   Inf    40    25    10
%     50     0    15    20   Inf    25
%    Inf    15     0    10    20   Inf
%     40    20    10     0    10    25
%     25   Inf    20    10     0    55
%     10    25   Inf    25    55     0];
% >> [d,r]=floyd(w)
%
% d =
%
%      0    35    45    35    25    10
%     35     0    15    20    30    25
%     45    15     0    10    20    35
%     35    20    10     0    10    25
%     25    30    20    10     0    35
%     10    25    35    25    35     0
%
%
% r =
%
%     '11'     '162'    '153'    '154'    '15'     '16'
%     '261'    '22'     '23'     '24'     '245'    '26'
%     '351'    '32'     '33'     '34'     '35'     '346'
%     '451'    '42'     '43'     '44'     '45'     '46'
%     '51'     '542'    '53'     '54'     '55'     '516'
%     '61'     '62'     '643'    '64'     '615'    '66' 